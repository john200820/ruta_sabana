/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class RutaCircularLib implements RutaCircular {

    private final LinkedList<Parada> cola;

    public RutaCircularLib() {
        this.cola = new LinkedList<>();
    }

    public void agregar(Parada parada) {
        cola.addLast(parada);
    }

    public Parada paradaActual() {
        if (estaVacia()) return null;
        
        return cola.peekFirst();
    }

    public Parada siguiente() {
        if (estaVacia()) return null;
        
        Parada p = cola.removeFirst();
        cola.addLast(p);
        return cola.peekFirst();
    }

    public Parada anterior() {
        if (estaVacia()) return null;
        
        Parada p = cola.removeLast();
        cola.addFirst(p);
        return cola.peekFirst();
    }

    public Parada saltar(int n) {
        if (estaVacia()) return null;
        
        Collections.rotate(cola, -n);
        return cola.peekFirst();
    }

    public Parada eliminarActual() {
        if (estaVacia()) return null;
        
        return cola.removeFirst();
    }

    public int tiempoTotal() {
        int total = 0;
        for (Parada p : cola) {
            total += p.hashCode();
        }
        return total;
    }

    public int tamano() {
        return cola.size();
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();
        for (Parada p : cola) {
            nombres.add(p.getNombre());
        }
        return nombres;
    }

    private void getMinutos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}