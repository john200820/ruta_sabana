/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

/**
 *
 * @author ESTUDIANTES
 */
class Nodo {

    Nodo(Parada parada1) {
    }

    Nodo siguiente;
    Nodo anterior;
    Parada parada;
    
}
