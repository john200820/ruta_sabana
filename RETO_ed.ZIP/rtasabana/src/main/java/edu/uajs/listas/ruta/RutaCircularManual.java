/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamano;

    public RutaCircularManual() {
        this.primero = null;
        this.actual = null;
        this.tamano = 0;
    }

    public void agregar(Parada parada) {
        Nodo nuevo = new Nodo(parada);
        if (estaVacia()) {
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            
            Nodo ultimo = primero.anterior;

            
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            nuevo.siguiente = primero;
            primero.anterior = nuevo;
        }
        tamano++;
    }

    public Parada paradaActual() {
        if (estaVacia()) return null;
        return actual.parada;
    }

    public Parada siguiente() {
        if (estaVacia()) return null;
       
        actual = actual.siguiente;
        return actual.parada;
    }

    public Parada anterior() {
        if (estaVacia()) return null;
       
        actual = actual.anterior;
        return actual.parada;
    }

    public Parada saltar(int n) {
        if (estaVacia()) return null;
        if (n == 0) return actual.parada;

      
        n = n % tamano;

        if (n > 0) {
            for (int i = 0; i < n; i++) {
                actual = actual.siguiente;
            }
        } else if (n < 0) {
            for (int i = 0; i < -n; i++) {
                actual = actual.anterior;
            }
        }
        return actual.parada;
    }

    public Parada eliminarActual() {
        if (estaVacia()) return null;

        Parada eliminada = actual.parada;

        if (tamano == 1) {
            
            primero = null;
            actual = null;
        } else {
            
            Nodo previo = actual.anterior;
            Nodo proximo = actual.siguiente;

            previo.siguiente = proximo;
            proximo.anterior = previo;

            
            if (actual == primero) {
                primero = proximo;
            }

          
            actual = proximo;
        }

        tamano--;
        return eliminada;
    }

    public int tiempoTotal() {
        if (estaVacia()) return 0;

       
        int acumulado = 0;
        Nodo aux = primero;
        do {
            acumulado += aux.parada.hashCode();
            aux = aux.siguiente;
        } while (aux != primero);

        return acumulado;
    }

    public int tamano() {
        return tamano;
    }

    public boolean estaVacia() {
        return tamano == 0;
    }

    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();
        if (estaVacia()) return nombres;

        Nodo aux = actual;
        do {
            nombres.add(aux.parada.getNombre());
            aux = aux.siguiente;
        } while (aux != actual);

        return nombres;
    }
}
